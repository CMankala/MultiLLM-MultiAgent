# Paper 2: database searches to run through Villanova library access (about 30 minutes)

Run all four on the same day and note that date. Searching title and abstract only, Jan 2023 onward. Export **everything** the search returns (do not screen); I de-duplicate and screen.

## 1. PubMed (pubmed.ncbi.nlm.nih.gov), Advanced search, paste into the query box
```
("large language model*"[tiab] OR "large-language model*"[tiab] OR LLM[tiab] OR LLMs[tiab] OR "vision-language model*"[tiab] OR "vision language model*"[tiab] OR "multimodal large language model*"[tiab] OR "multimodal LLM*"[tiab] OR GPT-4*[tiab] OR GPT-5*[tiab] OR "foundation model*"[tiab])
AND
("multi-agent"[tiab] OR multiagent[tiab] OR "multiple agents"[tiab] OR agentic[tiab] OR "AI agent*"[tiab] OR "LLM agent*"[tiab] OR "language agent*"[tiab] OR "autonomous agent*"[tiab] OR "agent-based"[tiab] OR "agent framework"[tiab] OR "tool-augmented"[tiab] OR "tool use"[tiab] OR "tool-using"[tiab] OR orchestrat*[tiab] OR "role-playing"[tiab] OR debate[tiab])
AND
(radiolog*[tiab] OR "medical image*"[tiab] OR "medical imaging"[tiab] OR radiograph*[tiab] OR "chest x-ray*"[tiab] OR "computed tomography"[tiab] OR CT[tiab] OR MRI[tiab] OR "magnetic resonance"[tiab] OR patholog*[tiab] OR "whole slide"[tiab] OR "whole-slide"[tiab] OR histopatholog*[tiab] OR ophthalm*[tiab] OR fundus[tiab] OR "optical coherence tomography"[tiab] OR dermatolog*[tiab] OR dermoscop*[tiab] OR endoscop*[tiab] OR ultrasound[tiab] OR ultrasonograph*[tiab] OR echocardiograph*[tiab] OR mammograph*[tiab] OR "visual question answering"[tiab] OR "report generation"[tiab])
AND ("2023/01/01"[dp] : "2026/12/31"[dp])
```
**Export:** Save → Selection: *All results* → Format: **CSV** (and, if you can, a second save as **PubMed** format, .nbib). Note the result count.

## 2. Scopus (via Villanova Library → Databases → Scopus), Advanced document search
```
TITLE-ABS-KEY ( ( "large language model*" OR llm OR llms OR "vision-language model*" OR "vision language model*" OR "multimodal large language model*" OR "multimodal llm*" OR gpt-4* OR gpt-5* OR "foundation model*" )
AND ( "multi-agent" OR multiagent OR "multiple agents" OR agentic OR "ai agent*" OR "llm agent*" OR "language agent*" OR "autonomous agent*" OR "agent-based" OR "agent framework" OR "tool-augmented" OR "tool use" OR "tool-using" OR orchestrat* OR "role-playing" OR ( agent* W/3 ( collaborat* OR debate* OR role* ) ) )
AND ( radiolog* OR "medical imag*" OR radiograph* OR "chest x-ray*" OR "computed tomography" OR mri OR "magnetic resonance" OR patholog* OR "whole slide" OR "whole-slide" OR histopatholog* OR ophthalm* OR fundus OR "optical coherence tomography" OR dermatolog* OR dermoscop* OR endoscop* OR ultrasound OR echocardiograph* OR mammograph* OR "visual question answering" OR "report generation" ) )
AND PUBYEAR > 2022
```
**Export:** select all → Export → **CSV**, tick *Citation information*, *Bibliographical information*, *Abstract & keywords*. Scopus exports up to 20,000 rows, which is plenty. Note the count.

## 3. IEEE Xplore (ieeexplore.ieee.org via the library), Advanced search → Command search
```
("All Metadata":"large language model*" OR "All Metadata":LLM OR "All Metadata":"vision-language model*" OR "All Metadata":"multimodal large language model*")
AND ("All Metadata":"multi-agent" OR "All Metadata":multiagent OR "All Metadata":agentic OR "All Metadata":"AI agent*" OR "All Metadata":"LLM agent*" OR "All Metadata":"tool-augmented" OR "All Metadata":orchestrat*)
AND ("All Metadata":radiolog* OR "All Metadata":"medical imag*" OR "All Metadata":"chest x-ray" OR "All Metadata":"computed tomography" OR "All Metadata":MRI OR "All Metadata":patholog* OR "All Metadata":"whole slide" OR "All Metadata":ophthalm* OR "All Metadata":fundus OR "All Metadata":dermatolog* OR "All Metadata":endoscop* OR "All Metadata":ultrasound OR "All Metadata":"report generation")
```
Filter: Year 2023–2026. **Export:** Export → Citations → **CSV**, *Citation & Abstract*. If IEEE rejects the query for too many wildcards, drop the `*` from the first block and run it again.

## 4. Web of Science Core Collection (optional, but strengthens PRISMA item 7)
Advanced search, same three blocks as Scopus with `TS=( … )` and `PY=(2023-2026)`. Use `NEAR/3` in place of `W/3`.
**Export:** Export → Excel or Tab-delimited, *Full record*.

## Send me
- The 3–4 export files (upload them here).
- For each: the date run, the exact count returned, and any change you made to the string (e.g. a dropped wildcard).

arXiv and medRxiv are covered on my side: the field is preprint-heavy, so I run those plus backward and forward snowballing from the included set and the five reviews.
