import csv,json,collections,re,math
rows=list(csv.DictReader(open('fulltext_adjudicated.csv')))
inc=[r for r in rows if r['group']=='included' and r['system_of']==r['uid']]
# fill CT-Agent and add MedToolica from the October charting (records.jsonl H20, H19)
for r in inc:
    if r['uid']=='R2242':
        r.update(dict(modality='3D chest CT',task='VQA; report generation',control='C2',tier='E2',maturity='bench',same_model_control='N',same_tools_control='N',ablation='Y',stats='none',clinician_eval='N',external_validation='N',human_gate='N',code_link='N',peer_reviewed='N',read_level='full',calibration_reported='N',subgroup_reported='N',cost_or_tokens_reported='N'))
inc.append(dict(uid='H19',title='MedToolica: Finetuning-Free Agentic Compositional Tool Learning for 3D CT',year='2026',venue='Machine Learning and Knowledge Extraction',sources='other (web search, Oct 2026)',medium='Y',strict='N',modality='abdominal CT',task='measurement; VQA',control='C1',tier='E3',maturity='bench',same_model_control='N',same_tools_control='N',ablation='Y',stats='inferential',clinician_eval='N',external_validation='N',human_gate='N',code_link='N',peer_reviewed='Y',read_level='full',calibration_reported='N',subgroup_reported='N',cost_or_tokens_reported='N',group='included',system_of='H19'))
def yn(v):
    v=(v or '').strip().lower()
    return 'Y' if v.startswith('y') else ('N' if v.startswith('n') or v=='' else '?')
def wilson(k,n,z=1.96):
    if n==0: return (0,0)
    p=k/n; d=1+z*z/n; c=p+z*z/(2*n); a=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n)); return ((c-a)/d,(c+a)/d)
N=len(inc)
def share(name,k):
    lo,hi=wilson(k,N); return dict(k=k,n=N,share=round(k/N,3),lo=round(lo,3),hi=round(hi,3))
def mod(m):
    m=(m or '').lower()
    for lab,pat in [('pathology',r'patholog|slide|histo|wsi|h&e'),('chest X-ray',r'chest x-ray|cxr|chest radiograph|radiograph'),('CT',r'\bct\b|computed tomography|pet'),('MRI',r'mri|neuroimag|magnetic'),('ophthalmic',r'fundus|oct|ophthalm|retin|eye'),('ultrasound/echo',r'ultrasound|echo|sonograph'),('dermatology',r'derm|skin|ulcer'),('endoscopy/surgical video',r'endoscop|laparoscop|surgical|colonoscop'),('dental',r'dental|panoramic|jaw')]:
        if re.search(pat,m): return lab
    return 'mixed / other'
tier=collections.Counter((r['tier'] or '?').strip()[:2] for r in inc)
mat=collections.Counter(next((k for k in ['bench','retro','proto','sim','prosp'] if k in (r['maturity'] or '').lower()),'?') for r in inc)
stats=collections.Counter(next((k for k in ['inferential','repeat','none'] if k in (r['stats'] or '').lower()),'none') for r in inc)
ctrl=collections.Counter()
for r in inc:
    for c in set(re.findall(r'C[1-8]',r['control'] or '')): ctrl[c]+=1
S={}
S['same_model_control']=share('',sum(yn(r['same_model_control'])=='Y' for r in inc))
S['same_tools_control']=share('',sum(yn(r['same_tools_control'])=='Y' for r in inc))
S['component_ablation']=share('',sum(yn(r['ablation'])=='Y' for r in inc))
S['inferential_statistics']=share('',stats['inferential'])
S['no_variance_or_test']=share('',stats['none'])
S['tier_E2_or_above']=share('',tier['E2']+tier['E3'])
S['tier_E3']=share('',tier['E3'])
S['clinician_evaluation']=share('',sum(yn(r['clinician_eval'])=='Y' for r in inc))
S['external_validation']=share('',sum(yn(r['external_validation'])=='Y' for r in inc))
S['human_gate']=share('',sum(yn(r['human_gate'])=='Y' for r in inc))
S['code_link']=share('',sum(yn(r['code_link'])=='Y' for r in inc))
S['peer_reviewed']=share('',sum(yn(r['peer_reviewed'])=='Y' for r in inc))
S['calibration_reported']=share('',sum(yn(r['calibration_reported'])=='Y' for r in inc))
S['subgroup_reported']=share('',sum(yn(r['subgroup_reported'])=='Y' for r in inc))
S['cost_or_tokens_reported']=share('',sum(yn(r['cost_or_tokens_reported'])=='Y' for r in inc))
S['strict_rule']=share('',sum((r['strict'] or '').strip()=='Y' for r in inc))
S['medium_rule']=share('',sum((r['medium'] or '').strip()=='Y' for r in inc))
S['prospective_or_deployed']=share('',mat['prosp'])
S['full_text_read']=share('',sum(r['read_level']=='full' for r in inc))
yr=collections.Counter(r['year'] for r in inc)
out=dict(N=N,year=dict(sorted(yr.items())),tier=dict(tier),maturity=dict(mat),stats=dict(stats),control=dict(sorted(ctrl.items())),modality=dict(collections.Counter(mod(r['modality']) for r in inc).most_common()),shares=S)
json.dump(out,open('summary_v2.json','w'),indent=1)
with open('included_systems_v2.csv','w',newline='') as f:
    keys=['uid','title','year','venue','sources','read_level','medium','strict','modality','task','datasets_n','n_llm_agents','roles','tools','backbones','control','mechanisms','same_model_control','same_tools_control','ablation','stats','tier','maturity','clinician_eval','external_validation','human_gate','code_link','peer_reviewed','calibration_reported','subgroup_reported','cost_or_tokens_reported','key_numbers','notes','adjudication']
    w=csv.DictWriter(f,fieldnames=keys,extrasaction='ignore'); w.writeheader(); w.writerows(inc)
print(json.dumps({k:v for k,v in out.items() if k!='shares'},indent=0))
for k,v in S.items(): print(f"{k:26s} {v['k']:3d}/{v['n']} {v['share']*100:5.1f}%  [{v['lo']*100:.0f}-{v['hi']*100:.0f}]")
