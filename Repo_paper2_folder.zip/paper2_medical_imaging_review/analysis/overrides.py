# Lead-reviewer adjudication of loosely coded fields (verified against texts, 5 Nov 2026)
SAME_TOOLS_Y={'R0203','R1482','R1878','R1952','R1961','R2020','R2112','R2288','R2166','R2052','R2069','R2219'}   # matched single-agent control (same backbone, same tools/inputs)
CLIN_REMOVE={'R2002','R2091','R1963','R1952','R1696'}   # reference standard / benchmark validation / non-clinician users, not clinician rating of outputs
READER_WITH_WITHOUT={'R0611','R1853','R2001'}            # readers with vs without the system
GATE_REMOVE={'R2131','R2207','R2263'}                    # learner-in-loop / operator commands / optional simulation mode, not a gate before use
CALIB_Y={'R0464','R1941','R2134'}                        # calibration of the system output reported
SUBGROUP_Y={'R0671','R2000','R2001'}                     # results broken down by demographic group or site
COMPUTE_MATCHED_Y={'R2043','R2111'}
