import csv,glob,json,collections,re
ft=[]
for f in sorted(glob.glob('/home/claude/p2/search/ft/out[0-9][0-9].csv')): ft+=list(csv.DictReader(open(f)))
rec={r['uid']:r for r in csv.DictReader(open('/home/claude/p2/search/screened_ta.csv'))}
ADJ={ # uid: (new_group, reason)
 'R1830':('not_agents','multi-agent exchange only at training time (pseudo-label curation); deployed model non-agentic'),
 'R1843':('not_agents','critic distilled into actor; deployed model runs without multi-agent exchange'),
 'R1703':('not_medical','preclinical organoid microscopy, not medical imaging'),
 'R1860':('not_medical','in-vitro Cell Painting microscopy, not medical imaging'),
 'R1504':('not_medical','spatial transcriptomics, not medical imaging'),
 'R2186':('not_medical','EMG waveform plots, not medical imaging'),
 'R2139':('no_images','agents control image viewers by command; no agent processes or reasons about images'),
 'R2242':('included','lead adjudication: DeepSeek-V3 planner hands off to separate anatomy-specific LoRA-adapted MLLMs (distinct LLM components); Medium ~, Strict Y'),
 'R0219':('single_agent','lead adjudication: one GPT-4o calling CNN imaging tools and retrieval'),
 'R1741':('single_agent','lead adjudication: one frozen VLM in a zoom-and-recheck loop'),
}
DUP={'R0045':'R2002','R0263':'R2223'}   # record -> canonical system record
out=[]
for r in ft:
    r=dict(r); r['ft_group_coder']=r['group']; r['adjudication']=''
    if r['uid'] in ADJ: r['group'],r['adjudication']=ADJ[r['uid']]
    if r['uid']=='R2242': r['medium'],r['strict']='~','Y'
    r['system_of']=DUP.get(r['uid'],r['uid'])
    r['title']=rec[r['uid']]['title']; r['year']=rec[r['uid']]['year']; r['venue']=rec[r['uid']]['venue']; r['sources']=rec[r['uid']]['sources']
    out.append(r)
with open('fulltext_adjudicated.csv','w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(out[0].keys())); w.writeheader(); w.writerows(out)
inc=[r for r in out if r['group']=='included']
systems={r['system_of'] for r in inc}
print('included records',len(inc),'systems from search',len(systems))
print(collections.Counter(r['group'] for r in out))
