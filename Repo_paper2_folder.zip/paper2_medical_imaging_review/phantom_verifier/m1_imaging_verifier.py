"""M1 — verifier vs real segmentation-tool errors (protocol §3 M1; Paper 2 §4).

Structured-findings level: a segmentation tool produces volumes/diameters/laterality; the
drafter writes findings from them; the verifier re-checks numbers against the tool output.
The segmentation call is a pluggable hook: ``segment(image_path) -> dict of findings``.
Synthetic mode draws findings from the claims generator with the imaging field set and plants
the protocol's error kinds (label swap = source flip; scaled volume = source flip; dropped
structure = missing field; boundary leak = scaled). Real mode on Augie: implement ``segment``
with TotalSegmentator / nnU-Net over MSD or AMOS NIfTI files (see README).
"""
from __future__ import annotations
import os, sys
from . import e3_verifier


def segment(image_path: str) -> dict:
    """Hook for the real tool. Expected to return {field: value} with the IMAGING_FIELDS keys.
    Not callable without the tool and the data; raise so that nobody mistakes a stub for a scan."""
    raise RuntimeError("segment(): install TotalSegmentator/nnU-Net on Augie and implement this hook; "
                       "use --synthetic for the structured-findings dry run")


def main(argv=None) -> int:
    argv = list(argv if argv is not None else sys.argv[1:])
    if "--synthetic" not in argv:
        print("m1_imaging_verifier: real mode needs the segmentation hook (see docstring); running the "
              "structured-findings level only.", file=sys.stderr)
    return e3_verifier.main(argv + ["--domain", "imaging"])


if __name__ == "__main__":
    sys.exit(main())
