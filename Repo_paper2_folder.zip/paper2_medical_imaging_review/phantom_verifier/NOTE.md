Both modules are taken from the augie_harness package (experiments/); run them inside that package.
