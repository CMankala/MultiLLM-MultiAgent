"""E3 — verifier independence (protocol §1 E3; Paper 3 Fig. verifier; Paper 2 §4 analogue).

Drafter: cheap model. Verifiers: (i) same model, same source; (ii) same model, independent
source; (iii) different family, same source; (iv) stronger different family, same source.
Faults planted per case: copy, source_flip, reasoning. Records catch rate by fault class,
false alarms, review share and decision accuracy.
"""
from __future__ import annotations
import sys
from ..common import parser, load_config, out_path, record
from ..backends import make_backend, optional_backend
from ..records import RecordWriter
from ..parallel import run_items, concurrency_of
from ..tasks import claims


def verifier_configs(cfg):
    """(i) and (ii) need one model; (iii) and (iv) need a second family and are skipped when the
    configuration does not provide one -- the protocol forbids faking an independence test with
    the same model (see the substitution table in the runbook)."""
    cheap = make_backend(cfg, "cheap")
    configs = {"i_same_model_same_source": (cheap, False, 0.0),
               "ii_same_model_independent_source": (cheap, True, 0.0)}
    alt1 = optional_backend(cfg, "alt1"); judge = optional_backend(cfg, "judge")
    if alt1 is not None:
        configs["iii_other_family_same_source"] = (alt1, False, 0.10)
    if judge is not None:
        configs["iv_strong_other_family_same_source"] = (judge, False, 0.20)
    if alt1 is None or judge is None:
        print("e3_verifier: no second model family configured; the cross-family verifiers are "
              "skipped and P3-E3(c) stays untestable.", file=sys.stderr)
    return cheap, configs


def run_case(drafter, verifier, c, seed, independent, family_bonus, draft_text=None):
    if draft_text is None:
        d = drafter.complete(claims.drafter_prompt(c), seed=seed, meta=claims.drafter_meta(c))
    else:                                    # the draft already on file: no new drafter call
        class D: pass
        d = D(); d.text = draft_text; d.tokens_in = d.tokens_out = 0; d.latency_s = 0.0
    cl = claims.plant_faults(c, claims.parse_draft(c, d.text))
    source = c.independent if independent else c.snapshot
    vmeta = {"kind": "verifier", "item_id": c.case_id, "claims": cl, "has_source": True,
             "independent_source": independent, "family_bonus": family_bonus}
    v = verifier.complete(claims.verifier_prompt(c, cl, source), seed=seed + 1, meta=vmeta)
    verdicts = claims.parse_verdicts(v.text, len(cl), [x["field"] for x in cl])
    out = claims.outcome(c, cl, verdicts)
    class R: pass
    r = R(); r.tokens_in = d.tokens_in + v.tokens_in; r.tokens_out = d.tokens_out + v.tokens_out
    r.latency_s = d.latency_s + v.latency_s; r.calls = 1 if draft_text is not None else 2; r.output = v.text
    return r, out


def main(argv=None) -> int:
    p = parser("e3_verifier", __doc__); p.add_argument("--domain", default="equipment")
    a = p.parse_args(argv); cfg = load_config(a.config)
    drafter, configs = verifier_configs(cfg)
    cases = claims.generate(a.n, a.seed, domain=a.domain)
    exp = "e3_verifier" if a.domain == "equipment" else "m1_imaging_verifier"
    arm_names = ["no_verifier"] + list(configs)

    with RecordWriter(out_path(cfg, a, exp, drafter.model), keep_outputs=True) as w:
        # Resume at case granularity: a case whose every arm is recorded is skipped entirely; a
        # partially written one (at most the case interrupted by a kill) is redone and only its
        # missing arms are written.
        todo = [c for c in cases if not all(w.has(n, c.case_id) for n in arm_names)]
        w.note_resume(exp, len(todo))

        def stored_draft(c):
            """The draft already on file for this case, so that a verifier added later is paired with exactly the
            draft the earlier verifiers judged. None when there is none, or when it may have been cut at the 2000
            characters a record keeps (then the case is drafted again and only its missing arms are written)."""
            t = w.output_for("no_verifier", c.case_id)
            if t is None or len(t) >= 2000 or not claims.parse_draft(c, t):
                return None
            return t

        def one_case(c):
            """The no-verifier baseline plus every configured verifier, for one case."""
            prior = stored_draft(c)
            if prior is not None:
                class D: pass
                d = D(); d.text = prior; d.tokens_in = d.tokens_out = 0; d.latency_s = 0.0
            else:
                d = drafter.complete(claims.drafter_prompt(c), seed=a.seed, meta=claims.drafter_meta(c))
            cl = claims.plant_faults(c, claims.parse_draft(c, d.text))
            rows = [("no_verifier", drafter, d, claims.outcome(c, cl, ["verified"] * len(cl)))]
            for name, (vb, indep, bonus) in configs.items():
                if w.has(name, c.case_id):
                    continue
                r, out = run_case(drafter, vb, c, a.seed, indep, bonus, draft_text=prior)
                rows.append((name, vb, r, out))
            return rows

        for c, rows in zip(todo, run_items(one_case, todo, concurrency_of(cfg))):
            for name, backend, res, out in rows:
                if w.has(name, c.case_id):
                    continue
                w.write(record(exp, name, c.case_id, a.seed, backend, claims.drafter_prompt(c), res, out,
                               {} if name == "no_verifier" else {"drafter": drafter.model}))
        print(f"{exp}: wrote {w.n} records -> {w.path}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
