# Full-text screening and charting: multi-agent LLM systems in medical imaging (PRISMA-ScR)

For EACH row of your batch CSV, read the local file /home/claude/p2/search/ft/texts/<uid>.txt (already downloaded; do NOT browse the web). /home/claude/p2/search/ft/fetch_status.json gives, per uid, `level` (full = full text from arXiv PDF or Europe PMC; abstract_only = only title+abstract were reachable) and `src`. Files can be long: use Read with offset/limit or grep to find the method, experiments and results sections; read enough to decide and chart. Record read_level = full or abstract_only as given by the status file. Never guess content you did not read; for abstract_only rows decide the group from the abstract and chart only what the abstract states.

## Decision (group), exactly one
- included — Broad rule: (a) two or more LLM/VLM-instantiated components with their own roles or prompts interact at run time on a medical imaging task, or (b) an LLM component acts at run time inside a multi-agent system that processes medical images (the LLM need not view pixels itself, but the system must process medical images at run time). One backbone with several distinctly prompted roles that hand off counts under (a).
- single_agent — one LLM/VLM calling tools/models in a loop (tools may be neural nets) on a medical imaging task.
- not_agents — the "agents" are not LLMs (CNN modules, RL policies, fixed scripts) or there is no agentic interaction.
- no_images — the LLM agents never process or reason about medical images at run time (text/EHR/report-only, or images only offline / for dataset generation / for training).
- not_medical — not medical imaging (natural images, remote sensing, plants, general VQA). Veterinary imaging counts as medical.
- benchmark — a benchmark/evaluation-only paper with no new system (say so; if it introduces a multi-agent baseline system, choose included).
- review — secondary study.
- not_reachable.

Also for included: Medium rule (≥2 LLM agents with distinct roles and explicit hand-off of state) Y/N/~; Strict rule (control flow decided at run time by an LLM or inter-agent exchange: routing, debate, arbitration) Y/N/~.

## Charting fields (included only; for single_agent fill modality, task, backbone, headline result vs comparator only)
modality; task (report generation | VQA | classification/grading | segmentation/measurement | detection | workflow/automation | other); datasets and n cases; n_llm_agents; roles; tools; backbones; control (C1 fixed pipeline; C2 router/supervisor; C3 event-triggered + verifier loop; C4 negotiation; C5 parallel fan-out + arbiter; C6 LLM inside classical MAS; C7 LLM→formal model→solver; C8 debate/critique loop; combos allowed e.g. C2+C5); mechanisms (M1 schema+retry; M2 domain rules/triage gate/decision logic; M3 claim/value verification vs source; M4 grounding to closed vocab/retrieval; M5 execution feedback/self-correction; M6 best-of-N + judge; M7 restricted action space; M8 human escalation; M9 refusal; M10 audit trail; M11 sample-and-aggregate; M12 peer critique/debate; M13 guarantee by construction); same_model_control Y/N (same backbone used alone); same_tools_control Y/N (single agent given the same tools); ablation Y/N + what and effect; stats none|repeats|inferential; tier E0 (demo, no quality comparison) E1 (absolute only) E2 (comparison/ablation, no inferential stats or single run) E3 (paired/matched with inferential stats); maturity sim|bench|proto|retro|prospective; clinician_eval Y/N (how); external_validation Y/N; human_gate Y/N; code_link Y/N; peer_reviewed Y/N (venue); calibration_reported Y/N; subgroup_reported Y/N; cost_or_tokens_reported Y/N; key_numbers (headline vs comparator; same-tools/ablation numbers exactly as reported); notes.

## Output
Write <outfile> as CSV with columns:
uid,group,read_level,medium,strict,modality,task,datasets_n,n_llm_agents,roles,tools,backbones,control,mechanisms,same_model_control,same_tools_control,ablation,stats,tier,maturity,clinician_eval,external_validation,human_gate,code_link,peer_reviewed,calibration_reported,subgroup_reported,cost_or_tokens_reported,key_numbers,reason,notes
(one row per input uid, quote fields with commas; leave non-applicable fields empty). `reason` = one line why this group. Keep each cell concise (≤ 40 words), numbers exact. Do not quote more than a short phrase from any paper.
Reply with: counts per group, the list of included uids with titles, and any row you could not read.
