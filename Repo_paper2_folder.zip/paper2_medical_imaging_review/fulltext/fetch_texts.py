import csv,json,os,re,time,subprocess,urllib.parse,urllib.request,xml.etree.ElementTree as ET,glob,sys
UA={"User-Agent":"scoping-review-fulltext/1.0"}
def get(u,t=60):
    with urllib.request.urlopen(urllib.request.Request(u,headers=UA),timeout=t) as r: return r.read()
rec={r['uid']:r for r in csv.DictReader(open('../screened_ta.csv'))}
uids=[r['uid'] for f in sorted(glob.glob('ft[0-9]*.csv')) for r in csv.DictReader(open(f))]
status={}
if os.path.exists('fetch_status.json'): status=json.load(open('fetch_status.json'))
ns={"a":"http://www.w3.org/2005/Atom"}
def norm(t): return re.sub(r'[^a-z0-9]','',t.lower())
for u in uids:
    if u in status: continue
    r=rec[u]; out=f'texts/{u}.txt'; level='abstract_only'; src=''
    ax=r['arxiv']
    m=re.search(r'10\.48550/arxiv\.(\d{4}\.\d{4,5})',r['doi'])
    if not ax and m: ax=m.group(1)
    if not ax:  # title lookup on arXiv
        try:
            q='ti:"'+re.sub(r'["]','',r['title'])[:180]+'"'
            x=ET.fromstring(get("https://export.arxiv.org/api/query?"+urllib.parse.urlencode({"search_query":q,"max_results":3})))
            for e in x.findall("a:entry",ns):
                if norm(e.findtext("a:title",namespaces=ns))[:50]==norm(r['title'])[:50]:
                    ax=e.findtext("a:id",namespaces=ns).rsplit('/abs/',1)[-1]; ax=re.sub(r'v\d+$','',ax); break
            time.sleep(3)
        except Exception as ex: pass
    if ax:
        try:
            b=get(f"https://export.arxiv.org/pdf/{ax}",90)
            if b[:4]==b'%PDF':
                open(f'pdf/{u}.pdf','wb').write(b)
                subprocess.run(['pdftotext','-layout',f'pdf/{u}.pdf',out],timeout=120)
                level='full'; src=f'arXiv:{ax}'
            time.sleep(3)
        except Exception as ex: pass
    if level!='full':
        try:
            q=('DOI:"'+r['doi']+'"') if r['doi'] else ('EXT_ID:'+r['id']+' AND SRC:MED' if r['source']=='pubmed' else 'TITLE:"'+r['title'][:150]+'"')
            d=json.loads(get("https://www.ebi.ac.uk/europepmc/webservices/rest/search?"+urllib.parse.urlencode({"query":q,"format":"json","resultType":"lite"})))
            hits=d.get('resultList',{}).get('result',[])
            pmc=next((h.get('pmcid') for h in hits if h.get('pmcid')),None)
            if pmc:
                x=get(f"https://www.ebi.ac.uk/europepmc/webservices/rest/{pmc}/fullTextXML")
                t=ET.fromstring(x); txt=' '.join(' '.join(t.itertext()).split())
                if len(txt)>3000: open(out,'w').write(txt); level='full'; src=pmc
        except Exception as ex: pass
    if level!='full':
        open(out,'w').write(f"TITLE: {r['title']}\nVENUE: {r['venue']} {r['year']}\nDOI: {r['doi']}\n\nABSTRACT (full text not reachable from this environment):\n{r['abstract']}\n")
    status[u]={'level':level,'src':src,'chars':os.path.getsize(out)}
    json.dump(status,open('fetch_status.json','w'),indent=0)
import collections
print(collections.Counter(v['level'] for v in status.values()))
