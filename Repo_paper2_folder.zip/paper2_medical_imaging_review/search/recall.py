import json,csv,re,sys
def norm(t): return re.sub(r'[^a-z0-9]','',t.lower())
rows=list(csv.DictReader(open('raw_records.csv')))
T=[norm(r['title']) for r in rows]; ids={r['id'] for r in rows}
known=[('RadAgents','2509.20490','radagentsmultimodalagentic'),('RadFabric',None,'radfabricagenticaisystem'),('H03','2505.09787','amultimodalmultiagentframeworkforradiologyreport'),
('MedAIConsensus','2509.17353','medicalaiconsensus'),('WSI-Agents',None,'wsiagents'),('H09','2604.16729','agenticlargelanguagemodelsfortrainingfree'),
('Dialectic-Med','2604.11258','dialecticmed'),('AgentEye',None,'anautonomousmultimodalaiagentforevidencegrounded'),('UCAgents','2512.02485','ucagents'),
('MedChat','2506.07400','medchatamultiagent'),('AMANDA',None,'amandaagenticmedical'),('PathFinder','2502.08916','pathfinderamultimodalmultiagent'),
('MedToolica',None,'medtoolica'),('CT-Agent','2505.16229','ctagentamultimodalllmagent'),('NeuroOphth',None,'llmbasedmultiagentsystemforneuroophthalmic'),
('BT-RADS','2603.21494','agenticautomationofbtrads'),('MedAgent-Pro','2503.18968','medagentpro'),('SlideSeek','2506.20964',None),('MRGAgents','2505.18530',None),
('NeuroAgent','2605.06584','neuroagent'),('EVADE','2608.18833','evadeevidenceverified')]
hit=0
for n,a,t in known:
    f=(a in ids) if a else False
    if not f and t: f=any(t in x for x in T)
    hit+=f
    if not f: print('MISS',n)
print('recall',hit,'/',len(known))
