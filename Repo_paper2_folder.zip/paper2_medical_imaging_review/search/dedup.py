import csv,re,json,collections
def norm(t): return re.sub(r'[^a-z0-9]','',(t or '').lower())
rows=list(csv.DictReader(open('raw_records.csv')))
groups={}; key_of={}
uf={}
def find(x):
    while uf[x]!=x: uf[x]=uf[uf[x]]; x=uf[x]
    return x
for i,r in enumerate(rows):
    uf[i]=i
idx=collections.defaultdict(list)
for i,r in enumerate(rows):
    keys=[]
    if r['doi']: keys.append('doi:'+r['doi'].strip())
    m=re.search(r'arxiv[.:/ ]*(\d{4}\.\d{4,5})',(r['doi']+' '+r['id']).lower()) or (re.match(r'(\d{4}\.\d{4,5})',r['id']) if r['source']=='arxiv' else None)
    if r['source']=='arxiv': keys.append('ax:'+r['id'])
    m2=re.search(r'10\.48550/arxiv\.(\d{4}\.\d{4,5})',r['doi'])
    if m2: keys.append('ax:'+m2.group(1))
    t=norm(r['title'])
    if len(t)>25: keys.append('t:'+t[:80])
    if r['source']=='europepmc' and r['id'].startswith('MED:'): keys.append('pmid:'+r['id'][4:])
    if r['source']=='pubmed': keys.append('pmid:'+r['id'])
    for k in keys: idx[k].append(i)
for k,v in idx.items():
    for j in v[1:]:
        a,b=find(v[0]),find(j)
        if a!=b: uf[b]=a
cl=collections.defaultdict(list)
for i in range(len(rows)): cl[find(i)].append(i)
out=[]
pri={'pubmed':0,'europepmc':1,'arxiv':2}
for c,members in cl.items():
    ms=sorted(members,key=lambda i:(pri[rows[i]['source']], -len(rows[i]['abstract'])))
    b=dict(rows[ms[0]]); b['sources']=';'.join(sorted({rows[i]['source'] for i in members}))
    b['abstract']=max((rows[i]['abstract'] for i in members),key=len)
    b['arxiv']=next((rows[i]['id'] for i in members if rows[i]['source']=='arxiv'),'')
    b['uid']=f"R{len(out)+1:04d}"
    out.append(b)
with open('dedup_records.csv','w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=['uid','sources','source','id','arxiv','doi','year','title','venue','authors','pubtype','abstract']); w.writeheader()
    for b in out: w.writerow({k:b.get(k,'') for k in w.fieldnames})
c=collections.Counter(b['sources'] for b in out)
print('raw',len(rows),'unique',len(out)); print(c.most_common())
