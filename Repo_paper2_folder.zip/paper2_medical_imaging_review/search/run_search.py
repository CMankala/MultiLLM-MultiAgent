"""Paper 2 database search: PubMed (E-utilities), Europe PMC (REST), arXiv (API).
Run date recorded in the output. Usage: python run_search.py OUTDIR"""
import sys, json, time, csv, re, datetime, urllib.parse, urllib.request, xml.etree.ElementTree as ET
OUT = sys.argv[1]
UA = {"User-Agent": "scoping-review-search/1.0"}
def get(url, tries=4):
    for i in range(tries):
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=60) as r:
                return r.read()
        except Exception as e:
            time.sleep(3 * (i + 1)); err = e
    raise err

LLM = ['"large language model"', '"large language models"', '"large-language model"', 'LLM', 'LLMs',
       '"vision-language model"', '"vision-language models"', '"vision language model"', '"multimodal large language model"',
       '"multimodal large language models"', '"multimodal LLM"', 'GPT-4', 'GPT-4o', 'GPT-4V', '"foundation model"', '"foundation models"']
AGENT = ['"multi-agent"', 'multiagent', '"multiple agents"', 'agentic', '"AI agent"', '"AI agents"', '"LLM agent"', '"LLM agents"',
         '"language agent"', '"language agents"', '"autonomous agent"', '"autonomous agents"', '"agent-based"', '"agent framework"',
         '"tool-augmented"', '"tool use"', '"tool-using"', 'orchestration', 'orchestrator', '"role-playing"', 'debate']
LLM += ['multimodal', '"language model"', '"language models"', 'VLM', 'VLMs', 'MLLM', 'MLLMs', 'GPT', 'ChatGPT', 'Gemini', 'Claude', 'Qwen', 'LLaVA']
AGENT += ['agent', 'agents', 'orchestrated', '"tool calling"', '"tool learning"', 'ReAct']
MED = ['medical', 'clinical', 'radiology', 'radiological', 'radiologist', 'radiologists', 'pathology', 'pathologist', 'diagnosis', 'diagnostic', 'healthcare', 'biomedical', 'ophthalmology', 'dermatology', 'oncology', 'neuroimaging', 'neuroradiology', 'patient', 'patients', 'disease', 'cancer', 'tumor', 'tumour', 'lesion']
IMG = ['image', 'images', 'imaging', 'neuroimaging', 'visual', 'vision', 'scan', 'scans', 'slide', 'slides', 'x-ray', 'CT', 'VQA', 'radiology', 'radiological', '"medical image"', '"medical images"', '"medical imaging"', 'radiograph', 'radiographs', 'radiography',
       '"chest x-ray"', '"chest X-rays"', '"computed tomography"', 'MRI', '"magnetic resonance"', 'pathology', '"whole slide"', '"whole-slide"',
       'histopathology', 'ophthalmology', 'ophthalmic', 'fundus', '"optical coherence tomography"', 'dermatology', 'dermoscopy', 'endoscopy',
       'endoscopic', 'ultrasound', 'echocardiography', 'mammography', '"visual question answering"', '"report generation"']

rows = []
log = {"run_date_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds"), "sources": {}}

# ---- PubMed ----
def pm_block(terms): return "(" + " OR ".join(f"{t}[tiab]" for t in terms) + ")"
pm_q = " AND ".join([pm_block(LLM), pm_block(AGENT), pm_block(MED), pm_block(IMG)]) + ' AND ("2023/01/01"[dp] : "3000"[dp])'
base = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/"
r = json.loads(get(base + "esearch.fcgi?" + urllib.parse.urlencode({"db": "pubmed", "term": pm_q, "retmode": "json", "retmax": 10000})))
ids = r["esearchresult"]["idlist"]; log["sources"]["pubmed"] = {"query": pm_q, "count": int(r["esearchresult"]["count"]), "retrieved": len(ids),
                                                                "translation": r["esearchresult"].get("querytranslation", "")}
for i in range(0, len(ids), 200):
    x = ET.fromstring(get(base + "efetch.fcgi?" + urllib.parse.urlencode({"db": "pubmed", "id": ",".join(ids[i:i+200]), "retmode": "xml"})))
    for a in x.findall(".//PubmedArticle"):
        art = a.find(".//Article")
        title = "".join(art.find("ArticleTitle").itertext()) if art.find("ArticleTitle") is not None else ""
        ab = " ".join("".join(t.itertext()) for t in art.findall(".//AbstractText"))
        doi = next((e.text for e in a.findall(".//ArticleId") if e.get("IdType") == "doi"), "")
        yr = (a.findtext(".//PubDate/Year") or a.findtext(".//PubDate/MedlineDate") or "")[:4]
        au = "; ".join(f"{e.findtext('LastName')} {e.findtext('Initials') or ''}".strip() for e in art.findall(".//Author") if e.findtext('LastName'))
        pt = "; ".join(e.text for e in a.findall(".//PublicationType"))
        rows.append({"source": "pubmed", "id": a.findtext(".//PMID"), "doi": (doi or "").lower(), "title": title, "abstract": ab, "year": yr,
                     "venue": art.findtext(".//Journal/Title") or "", "authors": au, "pubtype": pt})
    time.sleep(0.4)

# ---- Europe PMC ----
def ep_block(terms): return "(" + " OR ".join(f"TITLE:{t} OR ABSTRACT:{t}" for t in terms) + ")"
ep_q = " AND ".join([ep_block(LLM), ep_block(AGENT), ep_block(MED), ep_block(IMG)]) + " AND FIRST_PDATE:[2023-01-01 TO 2026-12-31]"
cursor, got, total = "*", 0, None
while True:
    u = "https://www.ebi.ac.uk/europepmc/webservices/rest/search?" + urllib.parse.urlencode(
        {"query": ep_q, "format": "json", "pageSize": 1000, "cursorMark": cursor, "resultType": "core"})
    d = json.loads(get(u)); total = d.get("hitCount", 0)
    for it in d.get("resultList", {}).get("result", []):
        rows.append({"source": "europepmc", "id": f"{it.get('source')}:{it.get('id')}", "doi": (it.get("doi") or "").lower(),
                     "title": it.get("title", ""), "abstract": it.get("abstractText", ""), "year": str(it.get("pubYear", "")),
                     "venue": (it.get("journalInfo", {}) or {}).get("journal", {}).get("title", "") or it.get("bookOrReportDetails", {}).get("publisher", "") if isinstance(it.get("journalInfo"), dict) else it.get("source", ""),
                     "authors": it.get("authorString", ""), "pubtype": "; ".join((it.get("pubTypeList") or {}).get("pubType", []))})
        got += 1
    nc = d.get("nextCursorMark")
    if not nc or nc == cursor or not d.get("resultList", {}).get("result"): break
    cursor = nc; time.sleep(0.5)
log["sources"]["europepmc"] = {"query": ep_q, "count": total, "retrieved": got}

# ---- arXiv ----
def ax(t):
    t = t.strip('"'); q = f'"{t}"' if (" " in t or "-" in t) else t
    return f"abs:{q} OR ti:{q}"
ax_llm = ["large language model", "language model", "vision-language", "vision language", "multimodal", "LLM", "LLMs", "MLLM", "MLLMs", "VLM", "VLMs", "GPT", "foundation model"]
ax_agent = ["agent", "agents", "agentic", "multi-agent", "multiagent", "orchestrator", "orchestration", "tool-augmented", "tool use", "tool calling", "debate"]
ax_med = ["medical", "clinical", "radiology", "radiologist", "pathology", "diagnosis", "diagnostic", "healthcare", "biomedical", "ophthalmology", "dermatology", "oncology", "neuroimaging", "neuroradiology", "patient", "patients", "disease", "cancer", "tumor", "lesion"]
ax_img = ["image", "images", "imaging", "neuroimaging", "visual", "vision", "scan", "slide", "x-ray", "CT", "VQA", "radiology", "medical image", "medical imaging", "chest x-ray", "radiograph", "computed tomography", "MRI", "pathology", "whole slide",
          "histopathology", "ophthalmology", "fundus", "dermatology", "endoscopy", "ultrasound", "echocardiography", "mammography", "report generation"]
ax_q = " AND ".join("(" + " OR ".join(ax(t) for t in blk) + ")" for blk in (ax_llm, ax_agent, ax_med, ax_img))
start, got, total = 0, 0, None
ns = {"a": "http://www.w3.org/2005/Atom", "o": "http://a9.com/-/spec/opensearch/1.1/"}
while True:
    u = "https://export.arxiv.org/api/query?" + urllib.parse.urlencode({"search_query": ax_q, "start": start, "max_results": 500,
                                                                        "sortBy": "submittedDate", "sortOrder": "descending"})
    x = ET.fromstring(get(u)); total = int(x.findtext("o:totalResults", namespaces=ns) or 0)
    es = x.findall("a:entry", ns)
    for e in es:
        pub = e.findtext("a:published", namespaces=ns) or ""
        if pub[:4] < "2023": continue
        aid = (e.findtext("a:id", namespaces=ns) or "").rsplit("/abs/", 1)[-1]
        doi = e.findtext("{http://arxiv.org/schemas/atom}doi") or ""
        rows.append({"source": "arxiv", "id": re.sub(r"v\d+$", "", aid), "doi": doi.lower(), "title": " ".join((e.findtext("a:title", namespaces=ns) or "").split()),
                     "abstract": " ".join((e.findtext("a:summary", namespaces=ns) or "").split()), "year": pub[:4], "venue": "arXiv",
                     "authors": "; ".join(a.findtext("a:name", namespaces=ns) for a in e.findall("a:author", ns)), "pubtype": "preprint"})
        got += 1
    start += 500
    if not es or start >= total: break
    time.sleep(3.5)
log["sources"]["arxiv"] = {"query": ax_q, "count": total, "retrieved_2023plus": got}

with open(f"{OUT}/raw_records.csv", "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
json.dump(log, open(f"{OUT}/search_log.json", "w"), indent=1)
print(json.dumps({k: {kk: vv for kk, vv in v.items() if kk != "query" and kk != "translation"} for k, v in log["sources"].items()}, indent=1))
