import csv,re,collections,json
rows=list(csv.DictReader(open('dedup_records.csv')))
NONLLM_AGENT=r'(contrast|chemical|therapeutic|pharmacolog\w*|anti\w*|imaging|infectious|chemotherapeutic|cytotoxic|biological|antimicrobial|antiviral|antifungal|antibacterial|sclerosing|radiopharmaceutical|neuroprotective|hypomethylating|alkylating|targeted|novel|single|nerve|paralytic|embolic|hemostatic|gadolinium-based|iodinated|ultrasound|microbubble|causative|etiologic|thrombolytic|anesthetic|immunosuppressive|cleaning|disinfecting|reducing|oxidizing|capping|bulking|sensitizing|sclerosant|lytic|tocolytic|inotropic|vasoactive|antiplatelet|antithrombotic|biologic|disease-modifying|osmotic)\s+agents?'
STRONG=r'multi-?agent|agentic|\bai agents?\b|\bllm[- ]?(based )?agents?\b|language[- ]model agents?|\bagents?\b[^.]{0,80}\b(llm|gpt|language model|vlm|mllm)|\b(llm|gpt|language model|vlm|mllm)s?\b[^.]{0,80}\bagents?\b|orchestrat|tool[- ](use|using|calling|augmented|learning)|react\b|autonomous agent|agent framework|agent system|debate'
out=collections.Counter(); keep=[]
for r in rows:
    txt=(r['title']+' . '+r['abstract']).lower()
    pt=r['pubtype'].lower()
    if re.search(r'\b(editorial|comment|letter|news|erratum|published erratum|retraction)\b',pt) and not re.search(r'journal article|research-article|preprint',pt):
        r['pre']='X_nonprimary_type'
    elif not r['abstract'].strip() and not re.search(STRONG,txt):
        r['pre']='X_no_abstract_no_agent_term'
    else:
        clean=re.sub(NONLLM_AGENT,' ',txt)
        LLMT=r'\bllms?\b|language models?|\bgpt|\bvlms?\b|\bmllms?\b|vision[- ]language|chatgpt|gemini|claude|qwen|llava|foundation models?|deepseek|llama'
        has_agent=re.search(r'\bagent|orchestrat|tool[- ](use|using|calling|augmented|learning)|debate|\breact\b',clean)
        strong=re.search(r'agentic|multi-?agent|\b(ai|artificial intelligence|autonomous|intelligent) agents?\b|gpt',clean)
        r['pre']='screen' if ((has_agent and re.search(LLMT,clean)) or strong) else ('X_no_LLM_term' if has_agent else 'X_agent_only_nonLLM_sense')
    out[r['pre']]+=1
print(out)
with open('prescreened.csv','w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
# recall check on known
import subprocess
