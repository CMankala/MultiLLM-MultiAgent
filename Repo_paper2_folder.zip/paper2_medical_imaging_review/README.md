# Paper 2 — Do several agents beat one? A scoping review of multi-agent LLM systems in medical imaging

Data and code for the scoping review (PRISMA-ScR) submitted to *Artificial Intelligence in Medicine*.
Author: Chaitanya Kumar Mankala (ORCID 0009-0000-7806-044X), Villanova University.

| Folder | Contents |
|---|---|
| `protocol/` | Search protocol and the methods as reported. The protocol was not registered; this repository's commit history time-stamps it. |
| `search/` | Search script, query log (5 Nov 2026, PubMed / Europe PMC / arXiv), 3,643 raw records, de-duplication (2,330), recall check (20/21). |
| `screening/` | Rule-based pre-screen (1,178 removed), title–abstract batches and decisions (1,152 screened). |
| `fulltext/` | Full-text batch sheets and coder output for the 340 records assessed; fetch status (278 full text, 62 abstract only). Paper texts are **not** redistributed; `fetch_texts.py` re-downloads open-access versions. |
| `analysis/` | Adjudication and override scripts; `included_systems_final.csv` (135 systems, all codes and key numbers); `summary_final.json`; `systems.bib`. |
| `second_coder/` | Codebook, 30-record sample, independent language-model second-coder codes, lead codes, `kappa.py`. |
| `phantom_verifier/` | Code and outputs for the phantom verifier illustration (Section 4). |
| `manuscript/` | Submitted manuscript and Supplementary Table S1. |

Reproduce the agreement statistics: `python second_coder/kappa.py second_coder/second_coder_sheet_filled.csv second_coder/lead_codes.csv`

Language-model assistance (Claude, Anthropic) was used for scripts, screening, first-pass charting and second coding; every decision on which the conclusions rest was adjudicated by the author. See the manuscript's declaration.
