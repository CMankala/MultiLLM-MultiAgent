"""Cohen's kappa between the lead codes and the second coder. Usage: python kappa.py second_coder_sheet_filled.csv lead_codes_HIDDEN.csv"""
import csv,sys,collections
sc={r['uid']:r for r in csv.DictReader(open(sys.argv[1]))}; ld={r['uid']:r for r in csv.DictReader(open(sys.argv[2]))}
def kappa(a,b):
    n=len(a); po=sum(x==y for x,y in zip(a,b))/n
    ca,cb=collections.Counter(a),collections.Counter(b); pe=sum(ca[k]*cb[k] for k in set(a)|set(b))/n/n
    return po,(po-pe)/(1-pe) if pe<1 else 1.0
gcol=[c for c in next(iter(sc.values())).keys() if c.startswith('group')][0]
pairs=[(ld[u]['group'],sc[u][gcol].strip().lower()) for u in ld if u in sc and sc[u][gcol].strip()]
a,b=zip(*pairs); po,k=kappa(a,b); print(f"inclusion group: n={len(a)} agreement={po:.2f} kappa={k:.2f}")
binc=[('included' if x=='included' else 'not') for x in a],[('included' if y=='included' else 'not') for y in b]
po,k=kappa(*binc); print(f"include vs not:  n={len(a)} agreement={po:.2f} kappa={k:.2f}")
fields=[('same_model_control','same_model'),('same_tools_control','same_tools'),('strict','strict'),('tier','evidence_tier'),('clinician_eval','clinician')]
for lf,key in fields:
    col=[c for c in next(iter(sc.values())).keys() if key in c][0]
    p=[(ld[u][lf].upper(),sc[u][col].strip().upper()[:2 if lf=='tier' else 1]) for u in ld if u in sc and ld[u][lf] and sc[u][col].strip()]
    if len(p)>=3: a,b=zip(*p); po,k=kappa(a,b); print(f"{lf:20s} n={len(a)} agreement={po:.2f} kappa={k:.2f}")
