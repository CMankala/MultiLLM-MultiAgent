# Second-coder codebook (Paper 2: multi-agent LLM systems in medical imaging)

You code **30 papers** independently. Do not look at anyone else's codes. Open each paper from the link; read the methods and the results tables. About 8–10 minutes per paper; roughly 4–5 hours in all.

## 1. Group (every paper), one of
- **included**: two or more LLM/VLM components with their own roles or prompts interact *at run time* on a *medical imaging* task; or an LLM acts at run time inside a multi-agent system that processes medical images. One model playing several distinctly prompted roles that hand off to each other counts.
- **single_agent**: one LLM/VLM calling tools (tools may be neural networks, e.g. a CNN classifier) in a loop.
- **not_agents**: the "agents" are not LLMs (CNNs, RL policies, scripts), or the multi-agent part runs only during training/data generation.
- **no_images**: the agents never process or reason about medical images at run time (text, reports, EHR only).
- **not_medical**: not medical imaging (natural images, lab microscopy, omics, signals such as EMG).
- **benchmark**: evaluation-only paper that introduces no new system.

## 2. If included, also code
- **same_model_control**: Y if the paper compares with the same backbone used alone (one call, no agents).
- **same_tools_control**: Y only if the paper compares with a *single agent* that has the *same backbone and the same tools/inputs* as the multi-agent system. A different system, a bare model, or a human reader is N.
- **strict_rule**: Y if control flow is decided at run time by an LLM or by exchange between agents (routing, debate, arbitration); N if a fixed script; ~ if unsure.
- **evidence_tier**: E0 demonstration, no quality comparison; E1 absolute performance only; E2 comparison or ablation without inferential statistics; E3 paired/matched comparison with an inferential test.
- **clinician_evaluation**: Y if clinicians rated the system's outputs or took part in a reader study; N if only metrics, benchmarks or LLM judges.

Fill in `second_coder_sheet.csv` and send it back. Agreement (Cohen's kappa) is computed by `kappa.py`.
